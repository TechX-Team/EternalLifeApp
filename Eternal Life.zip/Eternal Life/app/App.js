import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Animated } from "react-native";
import { NavigationContainer, DefaultTheme, DarkTheme } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { StatusBar } from "expo-status-bar";
import { DEFAULT_TRANSLATION } from "@env"; // from .env

// Screens
function HomeScreen({ navigation, toggleTheme, theme }) {
  const fadeAnim = new Animated.Value(0);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1200,
      useNativeDriver: true,
    }).start();
  }, []);

  return (
    <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
      <Text style={styles.title}>📖 Eternal Life</Text>
      <Text style={styles.subtitle}>Default Translation: {DEFAULT_TRANSLATION}</Text>

      <TouchableOpacity style={styles.button} onPress={toggleTheme}>
        <Text style={styles.buttonText}>
          Switch to {theme === "light" ? "Dark" : "Light"} Theme
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate("Bible")}
      >
        <Text style={styles.buttonText}>Go to Bible</Text>
      </TouchableOpacity>
    </Animated.View>
  );
}

function BibleScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bible Reader</Text>
      <Text style={styles.subtitle}>Genesis → Revelation Coming Soon...</Text>
    </View>
  );
}

const Stack = createStackNavigator();

export default function App() {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <NavigationContainer theme={theme === "light" ? DefaultTheme : DarkTheme}>
      <StatusBar style={theme === "light" ? "dark" : "light"} />
      <Stack.Navigator>
        <Stack.Screen name="Home">
          {(props) => <HomeScreen {...props} toggleTheme={toggleTheme} theme={theme} />}
        </Stack.Screen>
        <Stack.Screen name="Bible" component={BibleScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#007AFF",
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
  },
});