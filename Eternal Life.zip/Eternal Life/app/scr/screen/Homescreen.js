import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Animated, useColorScheme } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen({ navigation }) {
  const colorScheme = useColorScheme();
  const [isDarkTheme, setIsDarkTheme] = useState(colorScheme === 'dark');
  const [verse, setVerse] = useState("Loading verse of the day...");
  const fadeAnim = new Animated.Value(0);

  const menuItems = [
    { name: 'Bible', icon: 'book', screen: 'BibleScreen' },
    { name: 'Notes', icon: 'document-text', screen: 'NotesScreen' },
    { name: 'Prayers', icon: 'hand-left', screen: 'PrayersScreen' },
    { name: 'To-Do', icon: 'checkmark-done', screen: 'TodoScreen' },
    { name: 'Quiz', icon: 'help-circle', screen: 'QuizScreen' },
  ];

  // Simulate fetching verse of the day
  useEffect(() => {
    setTimeout(() => {
      setVerse("“For God so loved the world...” — John 3:16");
    }, 1000);

    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 1500,
      useNativeDriver: true
    }).start();
  }, []);

  const themeStyles = isDarkTheme ? styles.darkTheme : styles.lightTheme;

  return (
    <ScrollView style={[styles.container, themeStyles.background]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={[styles.title, themeStyles.text]}>Eternal Life</Text>
        <TouchableOpacity onPress={() => setIsDarkTheme(!isDarkTheme)}>
          <Ionicons
            name={isDarkTheme ? 'sunny' : 'moon'}
            size={28}
            color={isDarkTheme ? '#FFD700' : '#333'}
          />
        </TouchableOpacity>
      </View>

      {/* Verse of the Day */}
      <Animated.View style={[styles.verseContainer, { opacity: fadeAnim }]}>
        <Text style={[styles.verseText, themeStyles.text]}>{verse}</Text>
      </Animated.View>

      {/* Menu */}
      <View style={styles.menuGrid}>
        {menuItems.map((item, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.menuItem, themeStyles.card]}
            onPress={() => navigation.navigate(item.screen)}
          >
            <Ionicons name={item.icon} size={32} color={isDarkTheme ? '#fff' : '#333'} />
            <Text style={[styles.menuText, themeStyles.text]}>{item.name}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 15,
    paddingTop: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold'
  },
  verseContainer: {
    padding: 15,
    borderRadius: 10,
    marginBottom: 20
  },
  verseText: {
    fontSize: 16,
    fontStyle: 'italic',
    textAlign: 'center'
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between'
  },
  menuItem: {
    width: '48%',
    paddingVertical: 25,
    marginBottom: 15,
    borderRadius: 12,
    alignItems: 'center'
  },
  menuText: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '500'
  },
  // Theme styles
  lightTheme: {
    background: { backgroundColor: '#f9f9f9' },
    text: { color: '#333' },
    card: { backgroundColor: '#fff', elevation: 2 }
  },
  darkTheme: {
    background: { backgroundColor: '#121212' },
    text: { color: '#fff' },
    card: { backgroundColor: '#1f1f1f', elevation: 2 }
  }
});