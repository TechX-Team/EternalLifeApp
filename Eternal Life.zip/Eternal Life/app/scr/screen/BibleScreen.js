// /app/src/screens/BibleScreen.js
import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from "react-native";
import { Picker } from "@react-native-picker/picker";
import * as Animatable from "react-native-animatable";
import bibleData from "../../../content-packs/translations/kjv.json"; // Full Bible JSON

export default function BibleScreen() {
  const [book, setBook] = useState("Genesis");
  const [chapter, setChapter] = useState(1);
  const [verses, setVerses] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load initial chapter
  useEffect(() => {
    loadChapter(book, chapter);
  }, []);

  const loadChapter = (selectedBook, selectedChapter) => {
    setLoading(true);
    setTimeout(() => {
      const chapterVerses = bibleData[selectedBook][selectedChapter] || [];
      setVerses(chapterVerses);
      setLoading(false);
    }, 300); // Small delay for animation effect
  };

  const handleBookChange = (newBook) => {
    setBook(newBook);
    setChapter(1);
    loadChapter(newBook, 1);
  };

  const handleChapterChange = (newChapter) => {
    setChapter(newChapter);
    loadChapter(book, newChapter);
  };

  return (
    <View style={styles.container}>
      {/* Book Picker */}
      <Picker
        selectedValue={book}
        style={styles.picker}
        onValueChange={handleBookChange}
      >
        {Object.keys(bibleData).map((b, index) => (
          <Picker.Item key={index} label={b} value={b} />
        ))}
      </Picker>

      {/* Chapter Picker */}
      <Picker
        selectedValue={chapter}
        style={styles.picker}
        onValueChange={handleChapterChange}
      >
        {Array.from({ length: Object.keys(bibleData[book]).length }, (_, i) => (
          <Picker.Item key={i} label={`${i + 1}`} value={i + 1} />
        ))}
      </Picker>

      {/* Bible Text */}
      {loading ? (
        <ActivityIndicator size="large" color="#007BFF" />
      ) : (
        <ScrollView style={styles.scroll}>
          <Animatable.View animation="fadeIn" duration={500}>
            {verses.map((verse, index) => (
              <Text key={index} style={styles.verse}>
                <Text style={styles.verseNumber}>{index + 1} </Text>
                {verse}
              </Text>
            ))}
          </Animatable.View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    backgroundColor: "#f8f9fa",
  },
  picker: {
    height: 50,
    marginVertical: 5,
  },
  scroll: {
    marginTop: 10,
  },
  verse: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 5,
  },
  verseNumber: {
    fontWeight: "bold",
    color: "#007BFF",
  },
});