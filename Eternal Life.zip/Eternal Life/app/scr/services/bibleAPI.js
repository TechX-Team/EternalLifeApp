// app/src/services/bibleApi.js
// Simple offline Bible API that reads a local JSON translation (kjv.json)
// Exposes: getVerseOfDay(), getRandomVerse(), getVerse(book, chapter, verse), search(text)

import AsyncStorage from '@react-native-async-storage/async-storage';
// adjust path if your content-packs folder is elsewhere
import kjv from '../../../content-packs/translations/kjv.json';

const FLAT_CACHE_KEY = 'eternal_flat_bible_v1';
let FLAT = null;

// Flatten the JSON once (lazy)
function buildFlat() {
  if (FLAT) return FLAT;
  const arr = [];
  for (const book of Object.keys(kjv)) {
    const chapters = kjv[book];
    for (const ch of Object.keys(chapters)) {
      const verses = chapters[ch];
      for (const v of Object.keys(verses)) {
        const id = `${book}|${ch}|${v}`;
        arr.push({
          id,
          book,
          chapter: ch,
          verse: v,
          text: verses[v]
        });
      }
    }
  }
  FLAT = arr;
  return arr;
}

// Return object: { id, book, chapter, verse, text, reference }
export async function getVerseOfDay() {
  try {
    const flat = buildFlat();
    if (!flat.length) return null;

    // Determine day-of-year
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now - start;
    const dayOfYear = Math.floor(diff / 86400000);

    const idx = dayOfYear % flat.length;
    const v = flat[idx];
    return {
      ...v,
      reference: `${v.book} ${v.chapter}:${v.verse}`
    };
  } catch (e) {
    console.warn('getVerseOfDay error', e);
    return null;
  }
}

export async function getRandomVerse() {
  const flat = buildFlat();
  if (!flat.length) return null;
  const idx = Math.floor(Math.random() * flat.length);
  const v = flat[idx];
  return { ...v, reference: `${v.book} ${v.chapter}:${v.verse}` };
}

export async function getVerse(book, chapter, verse) {
  const flat = buildFlat();
  const id = `${book}|${chapter}|${verse}`;
  const found = flat.find(x => x.id === id);
  return found ? { ...found, reference: `${found.book} ${found.chapter}:${found.verse}` } : null;
}

// Simple search — returns up to 'limit' results
export async function search(text, limit = 200) {
  if (!text || text.trim().length < 1) return [];
  const q = text.toLowerCase();
  const flat = buildFlat();
  const res = [];
  for (let i = 0; i < flat.length && res.length < limit; i++) {
    const v = flat[i];
    if (v.text.toLowerCase().includes(q) || v.book.toLowerCase().includes(q)) {
      res.push({ ...v, reference: `${v.book} ${v.chapter}:${v.verse}` });
    }
  }
  return res;
}