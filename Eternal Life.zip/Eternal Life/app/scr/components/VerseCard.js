import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function VerseCard({ verse }) {
  return (
    <View style={styles.card}>
      <Text style={styles.reference}>{verse.reference}</Text>
      <Text style={styles.text}>{verse.text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 4,
    marginBottom: 20
  },
  reference: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 8
  },
  text: {
    fontSize: 16,
    color: '#333'
  }
});