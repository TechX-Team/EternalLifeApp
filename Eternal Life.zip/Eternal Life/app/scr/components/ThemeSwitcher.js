import React from 'react';
import { View, Switch, Text, StyleSheet } from 'react-native';

export default function ThemeSwitcher({ theme, setTheme }) {
  return (
    <View style={styles.container}>
      <Text style={{ color: theme === "light" ? "#000" : "#fff", fontSize: 16 }}>
        {theme === "light" ? "Light Mode" : "Dark Mode"}
      </Text>
      <Switch
        value={theme === "dark"}
        onValueChange={(val) => setTheme(val ? "dark" : "light")}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: 20 
  }
});