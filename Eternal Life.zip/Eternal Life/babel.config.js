// babel.config.js
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      [
        'module-resolver',
        {
          root: ['./app/src'],
          alias: {
            '@components': './app/src/components',
            '@screens': './app/src/screens',
            '@navigation': './app/src/navigation',
            '@services': './app/src/services',
            '@store': './app/src/store',
            '@db': './app/src/db',
            '@assets': './app/assets',
          },
        },
      ],
      'react-native-reanimated/plugin', // Needed if using Reanimated animations
    ],
  };
};