// metro.config.js
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Add support for custom file types like .txt (Bible text), .mp3 (audio), etc.
config.resolver.assetExts.push('txt', 'mp3', 'wav', 'json');

module.exports = config;